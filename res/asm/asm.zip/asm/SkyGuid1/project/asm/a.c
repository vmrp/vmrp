char isLittleEndian1(){
    union {
        int v;
        char isLittleEndian;
    }check;
    check.v = 1;
    return check.isLittleEndian;
}

char isLittleEndian2(){
    int i = 1;
    char j = *((char*)&i);
    return j;
}

int add(int a ,int b) {
	int c = a+b;
	return c;
}
